<?php
/**
 * Convert an Elementor page into clean HTML (keeps all content, drops the Elementor layout)
 * so that text edits, SEO and keyword work are reliable. Backed up and undoable.
 */
defined( 'ABSPATH' ) || exit;

/** Turn Elementor elements into plain semantic HTML in reading order. $unknown collects widget types that had no text to carry over. */
function csa_th_render( array $els, array &$unknown, array &$count ) {
	$h = '';
	foreach ( $els as $el ) {
		$type = $el['elType'] ?? '';
		$s    = (array) ( $el['settings'] ?? array() );
		if ( 'widget' !== $type ) {
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				$h .= csa_th_render( $el['elements'], $unknown, $count );
			}
			continue;
		}
		$w = $el['widgetType'] ?? '';
		$g = function ( $k ) use ( $s ) {
			$v = $s[ $k ] ?? '';
			return is_string( $v ) ? $v : '';
		};
		$url = function ( $k ) use ( $s ) {
			$v = $s[ $k ] ?? array();
			return is_array( $v ) ? (string) ( $v['url'] ?? '' ) : '';
		};
		switch ( $w ) {
			case 'heading':
				$t = $g( 'title' );
				if ( '' === trim( wp_strip_all_tags( $t ) ) ) {
					break;
				}
				$sz = strtolower( $g( 'header_size' ) );
				$sz = in_array( $sz, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ? $sz : 'h2';
				$lk = $url( 'link' );
				$in = $lk ? '<a href="' . esc_url( $lk ) . '">' . $t . '</a>' : $t;
				$h .= "<{$sz}>" . $in . "</{$sz}>\n";
				$count['heading']++;
				break;
			case 'text-editor':
				$h .= trim( $g( 'editor' ) ) . "\n";
				$count['text']++;
				break;
			case 'html':
				$h .= trim( $g( 'html' ) ) . "\n";
				$count['html']++;
				break;
			case 'shortcode':
				$h .= trim( $g( 'shortcode' ) ) . "\n";
				break;
			case 'image':
				$im = (array) ( $s['image'] ?? array() );
				if ( ! empty( $im['url'] ) ) {
					$alt = '';
					if ( ! empty( $im['id'] ) ) {
						$alt = (string) get_post_meta( (int) $im['id'], '_wp_attachment_image_alt', true );
					}
					$tag = '<img src="' . esc_url( $im['url'] ) . '" alt="' . esc_attr( $alt ) . '">';
					$lk  = $url( 'link' );
					$tag = $lk ? '<a href="' . esc_url( $lk ) . '">' . $tag . '</a>' : $tag;
					$cap = $g( 'caption' );
					$h  .= '<p>' . $tag . '</p>' . ( $cap ? '<p><em>' . esc_html( $cap ) . '</em></p>' : '' ) . "\n";
					$count['image']++;
				}
				break;
			case 'button':
				$t = $g( 'text' );
				if ( '' !== trim( $t ) ) {
					$lk = $url( 'link' );
					$h .= '<p>' . ( $lk ? '<a href="' . esc_url( $lk ) . '">' . esc_html( $t ) . '</a>' : esc_html( $t ) ) . "</p>\n";
					$count['button']++;
				}
				break;
			case 'icon-list':
				$li = '';
				foreach ( (array) ( $s['icon_list'] ?? array() ) as $it ) {
					$t = (string) ( $it['text'] ?? '' );
					if ( '' === trim( $t ) ) {
						continue;
					}
					$lk  = is_array( $it['link'] ?? null ) ? (string) ( $it['link']['url'] ?? '' ) : '';
					$li .= '<li>' . ( $lk ? '<a href="' . esc_url( $lk ) . '">' . esc_html( $t ) . '</a>' : esc_html( $t ) ) . "</li>\n";
				}
				if ( $li ) {
					$h .= "<ul>\n" . $li . "</ul>\n";
					$count['list']++;
				}
				break;
			case 'image-box':
			case 'icon-box':
				$t = $g( 'title_text' );
				$d = $g( 'description_text' );
				$im = (array) ( $s['image'] ?? array() );
				if ( 'image-box' === $w && ! empty( $im['url'] ) ) {
					$h .= '<p><img src="' . esc_url( $im['url'] ) . '" alt="' . esc_attr( wp_strip_all_tags( $t ) ) . '"></p>' . "\n";
				}
				if ( '' !== trim( $t ) ) {
					$h .= '<h3>' . $t . "</h3>\n";
				}
				if ( '' !== trim( $d ) ) {
					$h .= '<p>' . $d . "</p>\n";
				}
				$count['box']++;
				break;
			case 'accordion':
			case 'toggle':
			case 'tabs':
				foreach ( (array) ( $s['tabs'] ?? array() ) as $tb ) {
					$t = (string) ( $tb['tab_title'] ?? '' );
					$c = (string) ( $tb['tab_content'] ?? '' );
					$h .= ( '' !== trim( $t ) ? '<h3>' . $t . "</h3>\n" : '' ) . ( '' !== trim( $c ) ? $c . "\n" : '' );
				}
				$count['tabs']++;
				break;
			case 'video':
				$v = $g( 'youtube_url' ) . $g( 'vimeo_url' );
				if ( $v ) {
					$h .= '<p><a href="' . esc_url( $v ) . '">' . esc_html( $v ) . "</a></p>\n";
				} else {
					$unknown['video'] = 1;
				}
				break;
			case 'divider':
			case 'spacer':
				break;
			default:
				// Unknown widget: carry over any plain text it holds so nothing is silently lost.
				$got = '';
				foreach ( array( 'title', 'title_text', 'description_text', 'description', 'editor', 'text', 'content', 'caption' ) as $k ) {
					$v = $g( $k );
					if ( '' !== trim( wp_strip_all_tags( $v ) ) ) {
						$got .= '<p>' . $v . "</p>\n";
					}
				}
				if ( $got ) {
					$h .= $got;
				} else {
					$unknown[ $w ] = 1;
				}
		}
	}
	return $h;
}

/** Convert one page. Returns array( ok, summary ) or array( error ). */
function csa_th_convert( $id ) {
	$p = csa_valid_post( $id );
	if ( ! $p ) {
		return array( 'error' => 'Page not found.' );
	}
	$g = csa_live_guard( $p );
	if ( $g ) {
		return $g;
	}
	if ( ! csa_is_elementor( $p->ID ) ) {
		return array( 'error' => 'This page is not built with Elementor, so it is already plain content. Edit it directly with replace_text.' );
	}
	list( $raw, $data ) = csa_el_load( $p->ID );
	if ( ! $data ) {
		return array( 'error' => 'No Elementor data found on this page.' );
	}
	$unknown = array();
	$count   = array( 'heading' => 0, 'text' => 0, 'html' => 0, 'image' => 0, 'button' => 0, 'list' => 0, 'box' => 0, 'tabs' => 0 );
	$html    = trim( csa_th_render( $data, $unknown, $count ) );
	if ( '' === $html ) {
		return array( 'error' => 'No text or content could be taken from this page, so nothing was changed.' );
	}
	// Safety check: every heading and paragraph text of the old page must be in the new HTML.
	$before = wp_strip_all_tags( $raw );
	$key    = substr( md5( uniqid( '', true ) ), 0, 10 );
	$all    = get_post_meta( $p->ID, '_csa_el_removed', true );
	$all    = is_array( $all ) ? $all : array();
	$all[ $key ] = array(
		'data'     => $raw,
		'mode'     => get_post_meta( $p->ID, '_elementor_edit_mode', true ),
		'template' => get_post_meta( $p->ID, '_wp_page_template', true ),
		'content'  => $p->post_content,
	);
	update_post_meta( $p->ID, '_csa_el_removed', wp_slash( array_slice( $all, -3, 3, true ) ) );
	$r = wp_update_post( array( 'ID' => $p->ID, 'post_content' => $html ), true );
	if ( is_wp_error( $r ) ) {
		return array( 'error' => $r->get_error_message() );
	}
	delete_post_meta( $p->ID, '_elementor_edit_mode' );
	delete_post_meta( $p->ID, '_elementor_data' );
	delete_post_meta( $p->ID, '_elementor_css' );
	csa_clear_cache( $p->ID );
	csa_log( csa_t( 'Converted from Elementor to clean HTML' ) . ' #' . $p->ID . ' ' . $p->post_title, array( 'type' => 'unel', 'post' => (int) $p->ID, 'key' => $key ) );
	return array(
		'ok'      => true,
		'summary' => $count,
		'words'   => count( preg_split( '/\s+/u', trim( wp_strip_all_tags( $html ) ), -1, PREG_SPLIT_NO_EMPTY ) ),
		'not_carried_over' => array_keys( $unknown ),
		'note'    => 'The page is now plain HTML in the normal editor. Elementor layout, columns and styling are gone (the theme styles it now). Edit it with replace_text.',
	);
}

function csa_th_undo( $id, $key ) {
	$all = get_post_meta( $id, '_csa_el_removed', true );
	if ( ! is_array( $all ) || ! isset( $all[ $key ] ) ) {
		return new WP_Error( 'undo', csa_t( 'The saved copy for this change is no longer available.' ) );
	}
	$d = $all[ $key ];
	update_post_meta( $id, '_elementor_data', wp_slash( $d['data'] ) );
	update_post_meta( $id, '_elementor_edit_mode', $d['mode'] ? $d['mode'] : 'builder' );
	wp_update_post( array( 'ID' => $id, 'post_content' => $d['content'] ) );
	csa_clear_cache( $id );
	unset( $all[ $key ] );
	update_post_meta( $id, '_csa_el_removed', wp_slash( $all ) );
	return true;
}

/** Append a short line of real links ("Learn more: A · B · C") to the end of the page text. Works on Elementor and normal pages. */
function csa_th_links( $in ) {
	$p = csa_valid_post( $in['id'] ?? 0 );
	if ( ! $p ) {
		return array( 'error' => 'Page not found.' );
	}
	$g = csa_live_guard( $p );
	if ( $g ) {
		return $g;
	}
	$parts = array();
	foreach ( array_slice( (array) ( $in['links'] ?? array() ), 0, 6 ) as $l ) {
		$u = trim( (string) ( $l['url'] ?? '' ) );
		$a = trim( sanitize_text_field( $l['anchor'] ?? '' ) );
		if ( '' === $u || '' === $a ) {
			continue;
		}
		$u = 0 === strpos( $u, '/' ) ? home_url( $u ) : $u;
		if ( ! wp_http_validate_url( $u ) ) {
			continue;
		}
		$parts[] = '<a href="' . esc_url( $u ) . '">' . esc_html( $a ) . '</a>';
	}
	if ( ! $parts ) {
		return array( 'error' => 'No valid link given. Each link needs a url (starting with / or https://) and an anchor text.' );
	}
	$label = trim( sanitize_text_field( $in['label'] ?? '' ) );
	$label = '' !== $label ? $label : csa_t( 'Learn more' );
	$html  = '<p>' . esc_html( $label ) . ': ' . implode( ' · ', $parts ) . "</p>\n";
	$u     = csa_jobs_append( $p->ID, $html );
	if ( is_wp_error( $u ) ) {
		return array( 'error' => $u->get_error_message() );
	}
	csa_log( csa_t( 'Added related links to' ) . ' #' . $p->ID . ': ' . $p->post_title, $u );
	return array( 'ok' => true, 'added' => count( $parts ), 'note' => 'A line with real clickable links was added at the end of the page text.' );
}

function csa_th_tool() {
	return array(
		array(
			'name'         => 'fix_heading_levels',
			'description'  => 'Fix heading LEVELS of ONE page with no AI and no text change. mode "one_h1": the page must have exactly one H1; extra H1 headings inside the content become H2 (the theme\'s page title counts as the H1 when it shows one). mode "two_h2": H3-H6 headings become H2 until the page has at least 2 H2. Use this instead of replace_text/edit_content for heading levels. Undoable.',
			'input_schema' => csa_schema( array( 'id' => array( 'type' => 'integer' ), 'mode' => array( 'type' => 'string', 'enum' => array( 'one_h1', 'two_h2' ) ) ), array( 'id', 'mode' ) ),
		),
		array(
			'name'         => 'add_related_links',
			'description'  => 'Add a line of REAL clickable internal links (for example "আরও জানুন: Branch · Management · Academic") at the end of the page text. Use this for internal linking instead of replace_text (which cannot make links). Works on Elementor and normal pages, needs no HTML, undoable.',
			'input_schema' => csa_schema(
				array(
					'id'    => array( 'type' => 'integer' ),
					'label' => array( 'type' => 'string', 'description' => 'Short lead-in word(s), for example আরও জানুন.' ),
					'links' => array( 'type' => 'array', 'items' => array( 'type' => 'object', 'properties' => array( 'url' => array( 'type' => 'string' ), 'anchor' => array( 'type' => 'string' ) ), 'required' => array( 'url', 'anchor' ) ) ),
				),
				array( 'id', 'links' )
			),
		),
		array(
			'name'         => 'convert_to_html',
			'description'  => 'Convert ONE Elementor page into clean plain HTML (all headings, text, lists, images, links and buttons are kept in order; Elementor layout and styling are dropped, the theme styles it). Use it when a text/SEO/keyword edit on an Elementor page fails even once (Widget not found, no match): the owner has pre-approved this for text jobs. NEVER use it for design or layout jobs. After it, edit with replace_text / edit_content. Undoable.',
			'input_schema' => csa_schema( array( 'id' => array( 'type' => 'integer' ) ), array( 'id' ) ),
		),
	);
}

add_action( 'wp_ajax_csa_jobs_tohtml', function () {
	csa_guard( 'chat' );
	$r = csa_th_convert( (int) ( $_POST['id'] ?? 0 ) );
	if ( isset( $r['error'] ) ) {
		wp_send_json_error( $r['error'] );
	}
	wp_send_json_success( $r );
} );


/** Change heading levels without touching text or look. mode 'two_h2': promote H3-H6 so there are 2+ H2. mode 'one_h1': keep exactly one H1 on the live page. */
function csa_th_levels( $id, $mode ) {
	$p = csa_valid_post( $id );
	if ( ! $p ) {
		return array( 'error' => 'Page not found.' );
	}
	$g = csa_live_guard( $p );
	if ( $g ) {
		return $g;
	}
	$f   = csa_seo_collect( $p->ID );
	$h1s = is_array( $f ) ? (array) ( $f['h1'] ?? array() ) : array();
	$ttl = mb_strtolower( trim( wp_strip_all_tags( $p->post_title ) ) );
	$title_is_h1 = false;
	foreach ( $h1s as $h ) {
		if ( mb_strtolower( trim( $h ) ) === $ttl ) {
			$title_is_h1 = true;
		}
	}
	$need = 'two_h2' === $mode ? max( 1, 2 - count( (array) ( $f['h2'] ?? array() ) ) ) : 0;
	$keep = $title_is_h1 ? 0 : 1; // H1s allowed inside the content.
	$done = array();
	if ( csa_is_elementor( $p->ID ) ) {
		list( $raw, $data ) = csa_el_load( $p->ID );
		$seen = 0;
		$walk = function ( array &$els ) use ( &$walk, &$done, &$seen, $mode, $need, $keep ) {
			foreach ( $els as &$el ) {
				if ( 'widget' === ( $el['elType'] ?? '' ) && 'heading' === ( $el['widgetType'] ?? '' ) ) {
					$sz = strtolower( (string) ( $el['settings']['header_size'] ?? 'h2' ) );
					$tx = trim( wp_strip_all_tags( (string) ( $el['settings']['title'] ?? '' ) ) );
					if ( 'two_h2' === $mode && count( $done ) < $need && in_array( $sz, array( 'h3', 'h4', 'h5', 'h6' ), true ) && '' !== $tx ) {
						$el['settings']['header_size'] = 'h2';
						$done[] = $tx;
					} elseif ( 'one_h1' === $mode && 'h1' === $sz ) {
						$seen++;
						if ( $seen > $keep ) {
							$el['settings']['header_size'] = 'h2';
							$done[] = $tx;
						}
					}
				}
				if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
					$walk( $el['elements'] );
				}
			}
			unset( $el );
		};
		$walk( $data );
		if ( ! $done ) {
			return array( 'error' => 'Nothing to change: no matching heading widget found.' );
		}
		$bid = csa_el_save( $p->ID, $raw, $data );
		csa_log( csa_t( 'Heading levels changed on' ) . ' #' . $p->ID . ': ' . $p->post_title, array( 'type' => 'elementor', 'post' => (int) $p->ID, 'backup' => $bid ) );
	} else {
		$cnt = 0;
		$seen = 0;
		$re  = 'two_h2' === $mode ? '#<h([3-6])(\b[^>]*)>(.*?)</h\1>#is' : '#<h(1)(\b[^>]*)>(.*?)</h1>#is';
		$new = preg_replace_callback( $re, function ( $m ) use ( &$cnt, &$seen, &$done, $mode, $need, $keep ) {
			if ( 'two_h2' === $mode ) {
				if ( $cnt >= $need ) {
					return $m[0];
				}
			} else {
				$seen++;
				if ( $seen <= $keep ) {
					return $m[0];
				}
			}
			$cnt++;
			$done[] = trim( wp_strip_all_tags( $m[3] ) );
			return '<h2' . $m[2] . '>' . $m[3] . '</h2>';
		}, $p->post_content );
		if ( ! $done ) {
			return array( 'error' => 'Nothing to change: no matching heading in the page content.' );
		}
		$u = csa_snapshot_post( $p->ID );
		wp_update_post( array( 'ID' => $p->ID, 'post_content' => $new ) );
		csa_clear_cache( $p->ID );
		csa_log( csa_t( 'Heading levels changed on' ) . ' #' . $p->ID . ': ' . $p->post_title, $u );
	}
	return array( 'ok' => true, 'changed' => $done, 'title_is_h1' => $title_is_h1 );
}
