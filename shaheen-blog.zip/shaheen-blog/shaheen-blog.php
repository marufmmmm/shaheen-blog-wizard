<?php
/**
 * Plugin Name: Shaheen Blog
 * Plugin URI:  https://shaheen.edu.bd
 * Description: শাহীন শিক্ষা পরিবারের ব্লগ: নিজস্ব ডিজাইনের ব্লগ পেজ, AI দিয়ে পোস্ট তৈরির উইজার্ড, ক্রেডিট সিস্টেম ও অ্যাডমিন প্যানেল।
 * Version:     3.10.126
 * Requires at least: 6.0
 * Author:      Shaheen Education Family
 * Text Domain: shaheen-blog
 * Requires PHP: 7.4
 * License:     GPL-2.0-or-later
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SB_VERSION', '3.10.126');
define('SB_FILE', __FILE__);
define('SB_PATH', plugin_dir_path(__FILE__));
define('SB_URL', plugin_dir_url(__FILE__));

require_once SB_PATH . 'includes/helpers.php';
require_once SB_PATH . 'includes/post-types.php';
require_once SB_PATH . 'includes/credits.php';
require_once SB_PATH . 'includes/billing.php';
require_once SB_PATH . 'includes/images.php';
require_once SB_PATH . 'includes/apisync.php';
require_once SB_PATH . 'includes/seo.php';
require_once SB_PATH . 'includes/humanize.php';
require_once SB_PATH . 'includes/langfix.php';
require_once SB_PATH . 'includes/know.php';
require_once SB_PATH . 'includes/memory.php';
require_once SB_PATH . 'includes/ai.php';
require_once SB_PATH . 'includes/ajax.php';
require_once SB_PATH . 'includes/lock.php';
require_once SB_PATH . 'includes/blocks.php';
require_once SB_PATH . 'includes/social.php';
require_once SB_PATH . 'includes/extras.php';
require_once SB_PATH . 'includes/promos.php';
require_once SB_PATH . 'includes/phones.php';
require_once SB_PATH . 'includes/research.php';
require_once SB_PATH . 'includes/collect.php';
require_once SB_PATH . 'includes/press-import.php';
require_once SB_PATH . 'includes/news-notify.php';
require_once SB_PATH . 'includes/telegram-desk.php';
require_once SB_PATH . 'includes/social-share.php';
require_once SB_PATH . 'includes/fb-publish.php';
require_once SB_PATH . 'includes/fb-inbox.php';
require_once SB_PATH . 'includes/fb-manager.php';
require_once SB_PATH . 'includes/fb-token.php';
require_once SB_PATH . 'includes/fb-ai.php';
require_once SB_PATH . 'includes/fb-hub.php';
require_once SB_PATH . 'includes/collect-auto.php';
require_once SB_PATH . 'includes/yt-manage.php';
require_once SB_PATH . 'includes/yt-thumb.php';
require_once SB_PATH . 'includes/fb-link-yt.php';
require_once SB_PATH . 'includes/textfix.php';
require_once SB_PATH . 'includes/frontend.php';
require_once SB_PATH . 'includes/import.php';
require_once SB_PATH . 'includes/demo.php';
require_once SB_PATH . 'site-agent/loader.php';
if (is_admin()) {
    require_once SB_PATH . 'includes/admin.php';
}

register_activation_hook(__FILE__, 'sb_activate');
function sb_activate() {
    sb_register_types();
    sb_seed_categories();
    sb_create_blog_page();
    if (!get_option('sb_demo_done')) {
        sb_create_demo_posts();
        update_option('sb_demo_done', 1, false);
    }
    // Start the credit cycle for the installing user.
    SB_Credits::state(get_current_user_id());
    if (function_exists('csa_install')) {
        csa_install();
    }
    flush_rewrite_rules();
}

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('sb_phones_cron');
    flush_rewrite_rules();
});
